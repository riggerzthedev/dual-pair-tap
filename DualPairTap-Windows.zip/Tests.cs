using System;
public static class Tests {
    static int count;
    static void Check(bool b) { count++; if(!b) throw new Exception("Assertion "+count); }
    public static void Main() {
        // Exhaust every 8-event history: presses, releases and repeated events.
        for(int sequence=0;sequence<65536;sequence++) {
            Pair p=new Pair(65,68); bool a=false,b=false; int expected=0,n=sequence;
            for(int step=0;step<8;step++) {
                int ev=n&3; n>>=2; int key=ev<2?65:68; bool down=(ev&1)==0;
                bool prior=key==65?a:b;
                if(key==65)a=down;else b=down;
                if(down&&!prior)expected=key;
                if(!down&&expected==key)expected=key==65?(b?68:0):(a?65:0);
                Check(p.Update(key,down)==expected);
                Check(p.Active==0||p.Active==65&&a||p.Active==68&&b);
            }
        }
        Pair ad=new Pair(65,68),ws=new Pair(87,83);
        ad.Update(65,true); ws.Update(87,true); ad.Update(68,true); ws.Update(83,true);
        Check(ad.Active==68&&ws.Active==83);
        ad.Update(68,false); Check(ad.Active==65&&ws.Active==83);
        ws.Update(83,false); Check(ws.Active==87&&ad.Active==65);
        ad.Clear();ws.Clear();Check(ad.Active==0&&!ad.HeldA&&!ad.HeldB&&ws.Active==0);
        Console.WriteLine("PASS: "+count+" assertions; 65,536 histories and independent pairs.");
    }
}
