using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

// Independent last-input-priority pairs. No files, network, or keystroke logs.
public sealed class Pair {
    public readonly int A, B;
    public bool HeldA, HeldB;
    public int Active;
    public Pair(int a, int b) { A=a; B=b; }
    public int Update(int key, bool down) {
        bool held = key==A ? HeldA : HeldB;
        if (held==down) return Active; // Auto-repeat must not steal priority.
        if(key==A) HeldA=down; else HeldB=down;
        if(down) Active=key;
        else if(Active==key) Active=key==A ? (HeldB?B:0) : (HeldA?A:0);
        return Active;
    }
    public void Clear() { HeldA=HeldB=false; Active=0; }
}

public sealed class TapForm : Form {
    readonly Pair[] pairs={new Pair(65,68),new Pair(87,83)};
    readonly Label status=new Label(), live=new Label();
    readonly Button toggle=new Button();
    Native.Hook callback;
    IntPtr hook;
    bool enabled, controlHeld, failed;
    readonly Timer refresh=new Timer();
    public TapForm() {
        Text="Dual Pair Tap"; ClientSize=new Size(500,330);
        FormBorderStyle=FormBorderStyle.FixedSingle; MaximizeBox=false;
        BackColor=Color.FromArgb(24,27,34); ForeColor=Color.White;
        Font=new Font("Segoe UI",11);
        Label title=new Label {Text="A / D   +   W / S",Font=new Font("Segoe UI",22,FontStyle.Bold),Location=new Point(24,20),AutoSize=true};
        status.SetBounds(24,76,450,28); live.SetBounds(24,110,450,28);
        toggle.SetBounds(24,154,210,44); toggle.FlatStyle=FlatStyle.Flat;
        toggle.Click+=delegate { Toggle(); };
        Label help=new Label { Text="F8: toggle     F9: pause immediately\nRelease W/A/S/D before toggling.\nDisable Corsair FlashTap before enabling this app.\nNewest press wins within each pair.\nApplies to all keyboards while enabled.",Location=new Point(24,214),Size=new Size(460,108),Font=new Font("Segoe UI",10)};
        Controls.AddRange(new Control[]{title,status,live,toggle,help});
        callback=OnKey;
        hook=Native.SetWindowsHookEx(13,callback,Native.GetModuleHandle(null),0);
        if(hook==IntPtr.Zero) throw new System.ComponentModel.Win32Exception();
        refresh.Interval=100; refresh.Tick+=delegate { Render(); }; refresh.Start();
        FormClosing+=delegate { Stop(); if(hook!=IntPtr.Zero) Native.UnhookWindowsHookEx(hook); refresh.Dispose(); };
        Microsoft.Win32.SystemEvents.SessionSwitch+=SessionChanged;
        FormClosed+=delegate { Microsoft.Win32.SystemEvents.SessionSwitch-=SessionChanged; };
        Render();
    }
    void SessionChanged(object sender, Microsoft.Win32.SessionSwitchEventArgs e) { if(IsHandleCreated) BeginInvoke((Action)Stop); }
    void Render() {
        status.Text=failed?"Paused: Windows rejected remapped input.":enabled?"ENABLED — newest press wins":"PAUSED — normal keyboard input";
        status.ForeColor=enabled?Color.LightGreen:Color.Gold;
        live.Text="Output:   A/D = "+KeyName(pairs[0].Active)+"      W/S = "+KeyName(pairs[1].Active);
        toggle.Text=enabled?"Pause (F8)":"Enable (F8)";
    }
    static string KeyName(int k) { return k==0?"—":((char)k).ToString(); }
    void Toggle() {
        foreach(Pair p in pairs) if((Native.GetAsyncKeyState(p.A)&0x8000)!=0 || (Native.GetAsyncKeyState(p.B)&0x8000)!=0) {
            status.Text="Release W/A/S/D, then press F8 again."; return;
        }
        if(enabled) Stop(); else { foreach(Pair p in pairs)p.Clear(); failed=false; enabled=true; }
        Render();
    }
    void Stop() {
        enabled=false;
        foreach(Pair p in pairs) { if(p.Active!=0) Native.Send(p.Active,false); p.Clear(); }
    }
    IntPtr OnKey(int code,IntPtr msg,IntPtr data) {
        if(code<0) return Native.CallNextHookEx(hook,code,msg,data);
        Native.KeyEvent k=(Native.KeyEvent)Marshal.PtrToStructure(data,typeof(Native.KeyEvent));
        if((k.flags&16)!=0) return Native.CallNextHookEx(hook,code,msg,data);
        int m=msg.ToInt32(); bool down=m==0x100||m==0x104;
        if(m!=0x100&&m!=0x104&&m!=0x101&&m!=0x105) return Native.CallNextHookEx(hook,code,msg,data);
        if(k.vk==119 || k.vk==120) {
            if(k.vk==120) { if(down) Stop(); }
            else { if(down&&!controlHeld) { controlHeld=true; Toggle(); } if(!down) controlHeld=false; }
            return (IntPtr)1;
        }
        if(enabled) foreach(Pair p in pairs) if(k.vk==p.A||k.vk==p.B) {
            int before=p.Active, after=p.Update(k.vk,down);
            bool ok=true;
            if(before!=after) {
                if(before!=0) ok=Native.Send(before,false);
                if(ok&&after!=0) ok=Native.Send(after,true);
            }
            if(!ok) { Stop(); failed=true; }
            return (IntPtr)1;
        }
        return Native.CallNextHookEx(hook,code,msg,data);
    }
    [STAThread] public static void Main() {
        bool created;
        using(var mutex=new System.Threading.Mutex(true,"Local\\DualPairTap",out created)) {
            if(!created) { MessageBox.Show("Dual Pair Tap is already running."); return; }
            Application.EnableVisualStyles();
            try { Application.Run(new TapForm()); }
            catch(Exception e) { MessageBox.Show(e.Message,"Dual Pair Tap"); }
        }
    }
}

static class Native {
    public delegate IntPtr Hook(int code,IntPtr message,IntPtr data);
    [StructLayout(LayoutKind.Sequential)] public struct KeyEvent { public int vk,scan,flags,time; public UIntPtr extra; }
    [StructLayout(LayoutKind.Sequential)] struct Keyboard {public ushort vk,scan;public uint flags,time;public UIntPtr extra;}
    [StructLayout(LayoutKind.Sequential)] struct Mouse {public int x,y;public uint data,flags,time;public UIntPtr extra;}
    [StructLayout(LayoutKind.Explicit)] struct Union { [FieldOffset(0)] public Keyboard key; [FieldOffset(0)] public Mouse mouse; }
    [StructLayout(LayoutKind.Sequential)] struct Input {public uint type;public Union value;}
    public static bool Send(int vk,bool down) {
        ushort scan=(ushort)(vk==65?0x1e:vk==68?0x20:vk==87?0x11:0x1f);
        Input input=new Input {type=1,value=new Union {key=new Keyboard {scan=scan,flags=(uint)(8|(down?0:2))}}};
        return SendInput(1,new Input[]{input},Marshal.SizeOf(typeof(Input)))==1;
    }
    [DllImport("user32.dll",SetLastError=true)] static extern uint SendInput(uint count,Input[] inputs,int size);
    [DllImport("user32.dll",SetLastError=true)] public static extern IntPtr SetWindowsHookEx(int id,Hook callback,IntPtr module,uint thread);
    [DllImport("user32.dll")] public static extern bool UnhookWindowsHookEx(IntPtr hook);
    [DllImport("user32.dll")] public static extern IntPtr CallNextHookEx(IntPtr hook,int code,IntPtr message,IntPtr data);
    [DllImport("kernel32.dll",CharSet=CharSet.Auto)] public static extern IntPtr GetModuleHandle(string name);
    [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int key);
}
